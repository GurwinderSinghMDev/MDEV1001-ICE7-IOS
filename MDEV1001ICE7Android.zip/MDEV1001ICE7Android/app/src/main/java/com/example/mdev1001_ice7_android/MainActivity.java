package com.example.mdev1001_ice7_android;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.squareup.moshi.Moshi;
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.moshi.MoshiConverterFactory;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Moshi moshi = new Moshi.Builder().addLast(new KotlinJsonAdapterFactory()).build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://mdev1001-m2023-api.onrender.com/")
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build();

        MovieApi movieApi = retrofit.create(MovieApi.class);
        movieApi.fetchMovies().enqueue(new Callback<List<Movie>>() {
            @Override
            public void onResponse(Call<List<Movie>> call, Response<List<Movie>> response) {
                if (response.isSuccessful()) {
                    List<Movie> movies = response.body();
                    if (movies != null && !movies.isEmpty()) {
                        RecyclerView list = (RecyclerView)  findViewById(R.id.moviesRL);
                        MovieAdapter moviesAdapter = new MovieAdapter(movies);
                        list.setAdapter(moviesAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Movie>> call, Throwable t) {
            }
        });

    }

}