package com.example.mdev1001_ice7_android;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {
    private List<Movie> movie;

    public MovieAdapter(List<Movie> movieList) {
        this.movie = movieList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_movies, parent, false);
        return new ViewHolder(view);
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Movie movies = movie.get(position);
        holder.titleTextView.setText(movies.getTitle());
        holder.studioTextView.setText(movies.getStudio());
        holder.ratingTextView.setText(String.valueOf(movies.getCriticsRating()));

        if (Float.parseFloat(String.valueOf(movies.getCriticsRating())) > 7) {
            holder.ratingTextView.setBackgroundColor(Color.GREEN);
            holder.ratingTextView.setTextColor(Color.BLACK);
        } else if (Float.parseFloat(String.valueOf(movies.getCriticsRating())) > 5) {
            holder.ratingTextView.setBackgroundColor(Color.YELLOW);
            holder.ratingTextView.setTextColor(Color.BLACK);
        } else {
            holder.ratingTextView.setBackgroundColor(Color.RED);
            holder.ratingTextView.setTextColor(Color.WHITE);
        }

    }

    @Override
    public int getItemCount() {
        return movie.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView studioTextView;
        TextView ratingTextView;
        ConstraintLayout parentCL;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTV);
            studioTextView = itemView.findViewById(R.id.studioTV);
            ratingTextView = itemView.findViewById(R.id.ratingTV);
            parentCL = itemView.findViewById(R.id.parentCL);
        }
    }
}