package com.example.mdev1001_ice7_android;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MovieApi {
    @GET("api/list")
    Call<List<Movie>> fetchMovies();
}
